﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectoEVALUACION1_Gustavo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int frijolconqueso;
        int jalapeño;
        int pollo;
        double total;

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            frijolconqueso = Convert.ToInt32(textBox1.Text);
            jalapeño = Convert.ToInt32(textBox2.Text);
            pollo = Convert.ToInt32(textBox3.Text);
            total = (frijolconqueso * 0.30) + (jalapeño * 0.40) + (pollo * 0.45);
            textBox4.Text = "$" + total.ToString();
        }
    }
}
