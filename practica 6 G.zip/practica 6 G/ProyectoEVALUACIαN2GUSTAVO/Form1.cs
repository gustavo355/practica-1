﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoEVALUACIÓN2GUSTAVO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
        }
        double tarea1;
        double tarea2;
        double tarea3;
        double laboratorio1;
        double laboratorio2;
        double laboratorio3;
        double promediototal;



        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tarea1 = Convert.ToDouble(textBox1.Text);
            tarea2 = Convert.ToDouble(textBox2.Text);
            tarea3 = Convert.ToDouble(textBox3.Text);
            laboratorio1 = Convert.ToDouble(textBox4.Text);
            laboratorio2 = Convert.ToDouble(textBox5.Text);
            laboratorio3 = Convert.ToDouble(textBox6.Text);
            promediototal = (tarea1 + tarea2 + tarea3 + laboratorio1 + laboratorio2 + laboratorio3) / 6;
            textBox7.Text = promediototal.ToString();

            if (tarea1 > 10 || tarea1 < 0 || tarea2 > 10 || tarea2 < 0 || tarea3 > 10 || tarea3 < 0 || laboratorio1 > 10 || laboratorio1 < 0 || laboratorio2 > 10 || laboratorio2 < 0 || laboratorio3 > 10 || laboratorio3 < 0)
            {
                label8.Visible = true;

            }
            else if (promediototal >= 0 && promediototal <= 2.99)
            {
                label8.Visible = true;
                label8.Text = "Pongase las pilas mijito, ya no esta en el Kinder...\nNo se convierta en un veterano del INDEL";
                pictureBox4.Visible = true;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
            }
            else if (promediototal >= 3 && promediototal <= 5.99)
            {
                label8.Visible = true;
                label8.Text = "Mas dedicacion estudiante, debe mejorar sus notas en \nesta materia y las del resto";
                pictureBox3.Visible = true;
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox4.Visible = false;
            }
            else if (promediototal >= 6 && promediototal <= 6.99)
            {
                label8.Visible = true;
                label8.Text = "Muy bien, pero trata de mejorar en el siguiente periodo ";
                pictureBox2.Visible = true;
                pictureBox1.Visible = false;
                pictureBox4.Visible = false;
                pictureBox3.Visible = false;
            }
            else if (promediototal >= 7 && promediototal <= 10)
            {
                label8.Visible = true;
                label8.Text = "Grandioso,Excelemte...continua asi..";
                pictureBox1.Visible = true;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                pictureBox4.Visible = false;
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

    }

}